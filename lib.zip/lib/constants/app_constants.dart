class AppConstant {
  static const String svgString = 'assets/svg/chatinceviz.svg';
  static const String imageString = 'assets/images/chatinceviz.png';
}
